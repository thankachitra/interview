package datastructure;

public class BinaryTree {
	
	
	Node root;
	BinaryTree(int val)
	{
		root=new Node(val);
	}
	BinaryTree()
	{
		root=null;
	}
	public static void main(String a[])
	{
	
		BinaryTree tree=new BinaryTree(1);
		Node left_node=new Node(2);
		Node right_node=new Node(3);
		tree.root.left=left_node;
		tree.root.right=right_node;
		System.out.println(tree.root.key);
		System.out.println(tree.root.left.key);
		System.out.println(tree.root.right.key);
		
	}

}
